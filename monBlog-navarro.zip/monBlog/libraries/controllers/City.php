<?php

namespace Controllers;

use Models\articles;

session_start();

class City extends Controller
{
    protected $modelName = \Models\City::class;

    // Affichage de toutes les villes sur la page d'accueil
    public function index()
    {
        $city = $this->model->findAll();

        $articles = null;

        // Si l'utilisateur fait une recherche d'articles
        if(isset($_POST['search']) && !empty($_POST['search'])){

            $search = htmlspecialchars($_POST['search']);

            $articleModel = new Articles();
            $articles = $articleModel->showAllArticlesByTitle($search);
        }

        $pageTitle = "Accueil";

        \Renderer::render('articles/index', compact('pageTitle', 'city', 'articles'));
    }
}