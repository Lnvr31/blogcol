<?php

namespace Controllers;

session_start();

class Comment extends Controller
{
    protected $modelName = \Models\Comments::class;

    // Modification d'un commentaire
    public function update()
    {
        \Security::isNotAuth();

        $error = null;
        $article = null;
        $errorMsg = null;
        $comment = null;

        // Si il y a bien un ID dans l'url
        if (!empty($_GET['id']) && ctype_digit($_GET['id']) && !empty($_GET['article_id']) && ctype_digit($_GET['article_id']))
        {
            $get_id = htmlentities($_GET['id']);
            $article_id = htmlentities($_GET['article_id']);
            $city_id = htmlentities($_GET['id_city']);

            $comment = $this->model->find('id', $get_id);

            // Si l'ID existe bien
            if ($article !== false) {
                // Si le commentaire correspond à l'utilisateur connecté
                if ($comment['id_user'] == $_SESSION['id']) {

                    // Si l'utilisateur valide le formulaire
                    if (isset($_POST['validate'])) {

                        $content = nl2br(htmlspecialchars($_POST['content']));
                        date_default_timezone_set('Europe/paris');
                        $date = date('Y-m-d H:i:s');

                        // Si les champs sont tous remplis
                        if (!empty($content))
                        {
                            $this->model->update([$content, $date, $get_id],
                                'content = ?, updated_at = ?', "id"
                            );

                            \Http::redirect("index.php?controller=Article&task=show&id_city=$city_id&id=$article_id");
                        } else {
                            $errorMsg = 'Veuillez remplir le champ !';
                        }
                    }
                } else {
                    $error = "Vous n'êtes pas l'auteur de ce commentaire";
                }
            } else {
                $error = 'Aucun commentaire n\à été trouver !';
            }
        } else {
            $error = 'Aucun commentaire n\à été trouver !';
        }

        // Affichage
        $pageTitle = "Modifier mon commentaire";

        \Renderer::render('articles/updateComment', compact('pageTitle', 'comment', 'error', 'errorMsg'));
    }

    // Suppression d'un commentaire
    public function delete()
    {
        \Security::isNotAuth();

        if (!empty($_GET['id']) && ctype_digit($_GET['id']) && !empty($_GET['article_id']) && ctype_digit($_GET['article_id']))
        {
            $get_id = htmlentities($_GET['id']);
            $article_id = htmlentities($_GET['article_id']);
            $city_id = htmlentities($_GET['id_city']);
            $article_user_id = htmlentities($_GET['article_user']);
    
            $comment = $this->model->find('id', $get_id);
    
            // Vérification que l'utilisateur est bien l'auteur du commentaire pour pouvoir le supprimer
            if($comment['id_user'] == $_SESSION['id'] || $article_user_id == $_SESSION['id'])
            {
                $this->model->delete($get_id);
            }
            
            \Http::redirect("index.php?controller=Article&task=show&id_city=$city_id&id=$article_id");
        }
    }
}
