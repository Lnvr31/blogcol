<?php

namespace Controllers;

use Models\Articles;

session_start();

class UserProfile extends Controller
{
    protected $modelName = \Models\Users::class;

    // Afficher le profil de l'utilisateur
    public function showMyProfile()
    {
        \Security::isNotAuth();

        $user = $this->model->find('id', $_SESSION['id']);
        
        $articleModel = new Articles();

        $lastArticles = $articleModel->findAllArticlesBy($_SESSION['id'], 'C.city', 'city C ON C.id = A.id_city', 'a.id_user', 5);
    
        $articles = $articleModel->findAllArticlesBy($_SESSION['id'], 'C.city', 'city C ON C.id = A.id_city', 'a.id_user');
        $numberOfArticles = count($articles);

        // Affichage
        $pageTitle = "Mon profil";

        \Renderer::render('articles/UserProfile', compact('pageTitle', 'user', 'lastArticles', 'articles', 'numberOfArticles'));
    }

    public function editMyProfile()
    {
        \Security::isNotAuth();

        $id = htmlentities($_GET['id']);
        $error = null;
        $error2 = null;
        $articleModel = new Articles();
        $avatar = null;

        // Vérification du GET['id']
        if (isset($id) && !empty($id)) {
            if ($id == $_SESSION['id']) {
                $user = $this->model->find('id', $id);
            } else {
                \Http::redirect('index.php?controller=City&task=index');
            }
        } else {
            \Http::redirect('index.php?controller=City&task=index');
        }


        // Si l'utilisateur valide le formulaire
        if (isset($_POST['validate']))
        {
            $name = htmlspecialchars(($_POST['name']));
            $mail = htmlspecialchars(($_POST['mail']));
            $currentpassword = htmlspecialchars(($_POST['currentpassword']));
            $password = htmlspecialchars(($_POST['password']));
            $password2 = htmlspecialchars(($_POST['password2']));

            // Vérification nom et mail
            if (!empty($name) && !empty($mail)) {
                $verifName = \UserInfos::name($name);
                $verifMail = \UserInfos::mail($mail);

                //Si l'utilisateur change son nom
                if ($name !== $_SESSION['name']) {
                    if ($verifName !== true) {
                        $error = $verifName;
                    } else {
                        //Si l'utilisateur change aussi son mail
                        if ($mail !== $_SESSION['mail']) {
                            if ($verifMail !== true) {
                                $error = $verifMail;
                            } else {

                                echo 'success';
                                $this->model->update([$name, $mail, $id], 'username = ?, mail = ?', 'id');
                                $_SESSION['name'] = $name;
                                $_SESSION['mail'] = $mail;
                                \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                            }
                        } else {
                            $this->model->update([$name, $id], 'username = ?', 'id');
                            $_SESSION['name'] = $name;
                            \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                        }
                    }
                }
                // L'utilisateur change pas son nom 
                else {
                    // L'utilisateur change que son mail
                    if ($mail !== $_SESSION['mail']) {
                        if ($verifMail !== true) {
                            $error = $verifMail;
                        } else {
                            $this->model->update([$mail, $id], 'mail = ?', 'id');
                            $_SESSION['mail'] = $mail;
                            \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                        }
                    }
                    // Si l'utilisateur n'a changer aucune information dans le formulaire
                    else {
                        if (empty($password) && empty($password2) && !isset($_FILES['avatar']))
                            \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                    }
                }
            } else {
                $error = 'Veuillez remplir les champs du pseudo et de l\'adresse mail !';
            }


            // Vérification mot de passe
            if (!empty($password)) {
                // Si l'utilisateur à rentrer les 2 mots de passe
                if (!empty($password2)) {
                    $verifPassword = \UserInfos::password($password, $password2);

                    if (!empty($currentpassword))
                    {
                        if(password_verify($currentpassword, $user['password']))
                        {
                            if ($verifPassword !== true)
                            {
                                $error2 = $verifPassword;
                            } else {
                                $password = password_hash($password, PASSWORD_DEFAULT);
                                $this->model->update([$password, $id], 'password = ?', 'id');;
                                \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                            }
                        } else {
                            $error2 = 'Votre mot de passe n\'est pas correct !';     
                        }
                    } else {
                        $error2 = 'Vous devez saisir votre mot de passe actuel !';
                    }

                }
                // Si l'utilisateur à rentrer que le 1er mot de passe
                else {
                    $error2 = 'Vous devez confirmer votre mot de passe !';
                }
            } else {
                // Si l'utilisateur à rentrer que le 2eme mot de passe
                if (!empty($password2)) {
                    $error2 = 'Vous devez rentrer un mot de passe pour pouvoir le confirmé !';
                }
            }


            if(isset($_FILES['avatar']) && !empty($_FILES['avatar']['name']))
            {
                $verifAvatar = \FilesInfos::avatar(2100000);

                if ($verifAvatar[0] === true) {
                    $avatar = $verifAvatar[1];
                    $this->model->update([$avatar, $id], 'avatar = ?', 'id');
                    \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                } else {
                    $error = $verifAvatar;
                }     
            }
        }


        // Affichage
        $pageTitle = "Modifier mon profil";

        \Renderer::render('articles/editProfile', compact('pageTitle', 'avatar', 'error', 'error2', 'user'));
    }
}