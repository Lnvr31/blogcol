<?php

/* Vérifications des fichiers rentrées par l'utilisateur */
class FilesInfos
{
    public static function avatar($size)
    {
        $maxSize = $size;
        $extensions = ['jpg', 'png', 'gif', 'jpeg'];

        if ($_FILES['avatar']['size'] <= $maxSize) {
            $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));

            if (in_array($extensionUpload, $extensions)) {
                $save = "members/avatars/" . $_SESSION['id'] . "." . $extensionUpload;

                $result = move_uploaded_file($_FILES['avatar']['tmp_name'], $save);
                if ($result) {
                    $avatar =  $_SESSION['id'] . "." . $extensionUpload;
                    
                    return [true, $avatar];
                } else {
                    $avatarError = 'Il y a eu une erreur pendant l\'importation de votre document';
                }
            } else {
                $avatarError = 'Votre photo doit être au format JPG, JPEG, PNG ou GIF';
            }
        } else {
            $avatarError = 'Votre photo de profil ne doit pas dépasser 2Mo';
        }

        return $avatarError;
    }
}
