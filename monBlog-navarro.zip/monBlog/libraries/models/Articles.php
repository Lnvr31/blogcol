<?php

namespace Models;

class Articles extends Model
{
    protected $table = "articles";
}
