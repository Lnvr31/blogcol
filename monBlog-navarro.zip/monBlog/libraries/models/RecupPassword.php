<?php

namespace Models;

class RecupPassword extends Model
{
    protected $table = "recup_password";
}