<?php

namespace Models;

class Users extends Model
{
    protected $table = "users";
}