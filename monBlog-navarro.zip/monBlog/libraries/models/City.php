<?php

namespace Models;

class City extends Model
{
    protected $table = "city";
}