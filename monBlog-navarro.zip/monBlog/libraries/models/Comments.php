<?php

namespace Models;

class Comments extends Model
{
    protected $table = "comments";
}