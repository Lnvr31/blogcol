<?php

/* Vérifications des infos personnelles rentrées par l'utilisateur */

use Models\users;

class UserInfos
{
    // Vérification du nom saisi
    public static function name($name)
    {
        $userModel = new Users();
        $pseudoExist = $userModel->find('username', $name);

        if (strlen($name) < 4 || strlen($name) > 30) {
            $error = 'Votre pseudo doit contenir entre 4 et 30 caractères.';
        } else if ($pseudoExist !== false) {
            $error = 'Votre pseudo existe déjà !';
        } else if (!ctype_alnum($name)) {
            $error = 'Votre pseudo doît être une chaîne de caractères alphanumériques !';
        } else {
            return true;
        }

        return $error;
    }

    public static function mail($mail)
    {
        $userModel = new Users();
        $mailExist = $userModel->find('mail', $mail);

        if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            $error = 'Veuillez saisir une adresse email valide !';
        } else if ($mailExist !== false) {
            $error = 'Votre adresse email existe déjà !';
        } else {
            return true;
        }

        return $error;
    }

    public static function password($password, $password2)
    {
        $majuscule = preg_match('@[A-Z]@', $password);
        $minuscule = preg_match('@[a-z]@', $password);
        $chiffre = preg_match('@[0-9]@', $password);
        $noAlnum = preg_match('@[^a-zA-Z_0-9]@', $password);

        if (strlen($password) < 6) {
            $error = 'Votre mot de passe doit contenir au moins 6 caractères !';
        } else if ($password != $password2) {
            $error = 'Vos mot de passe ne correspondent pas !';
        } else if (!$majuscule || !$minuscule || !$chiffre || !$noAlnum) {
            $error = 'Votre mot de passe doit contenir au moins un caractère spécial, une majuscule, une miniscule et un chiffre !';
        } else {
            return true;
        }

        return $error;
    }
}