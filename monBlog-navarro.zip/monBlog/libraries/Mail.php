<?php

use PHPMailer\PHPMailer\PHPMailer;

// Paramétrage d'un envoie de mail
class Mail
{
    //public static function sendMail(string $mail, string $token)
    public static function sendMail(string $mail, string $subject, string $body)
    {
        $sendMail = new PHPMailer(true);

        $sendMail->isSMTP();
        $sendMail->Host = 'smtp.gmail.com';
        $sendMail->SMTPAuth = true;
        $sendMail->Username = 'loenannvr31@gmail.com';
        $sendMail->Password = 'vmeensekdkayievh';
        $sendMail->SMTPSecure = 'tls';
        $sendMail->Port = 587;
        $sendMail->CharSet = 'utf-8';
        $sendMail->addAddress($mail);
        $sendMail->setFrom('loenannvr31@gmail.com');
        $sendMail->isHtml();

        $sendMail->Subject = $subject;
        $sendMail->Body = $body;
    
        if (!$sendMail->send()) {
            $error = 'Le message n\a pas été envoyé !
        Erreurs :' . $sendMail->ErrorInfo;
            return $error;
        }
    }
}