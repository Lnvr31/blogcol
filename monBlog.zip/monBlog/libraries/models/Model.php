<?php

namespace Models;

use PHPMailer\PHPMailer\PHPMailer;

abstract class Model
{
    protected $pdo;
    protected $table;

    // Connexion à la base de données
    public function __construct()
    {
        $this->pdo = \Database::getPdo();
    }


    // Retourne un élément
    public function find(string $filter, string $info)
    {
        $query = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE $filter = ?");
        $query->execute([$info]);
        $item = $query->fetch();
        return $item;
    }

    // Retourne tous les éléments
    public function findAll(?string $order = ""): array
    {
        $sql = "SELECT * FROM {$this->table}";

        if($order){
            $sql .= " ORDER BY " . $order;
        }

        $results = $this->pdo->query($sql);
        $items = $results->fetchAll();

        return $items;
    }

    // Supprimer un élément
    public function delete(int $id): void
    {
        $query = $this->pdo->prepare("DELETE FROM {$this->table} WHERE id = :id");
        $query->execute(['id' => $id]);
    }

    // Insérer un élément
    public function insert(array $var = [], string $fields ): int
    {
        $query = $this->pdo->prepare("INSERT INTO {$this->table} " . $fields);
    
        $varlength = count($var);
        $values = [];

        for ($i=0; $i < $varlength; $i++) { 
            array_push($values, $var[$i]);
        }
        $query->execute($values);

        $lastId = $this->pdo->lastInsertId();

        return $lastId;
    }

    // Mettre à jour un élément
    public function update(array $var = [], string $fields, string $filter): void
    {
        $query = $this->pdo->prepare("UPDATE {$this->table} SET " . $fields . "  
        WHERE $filter = ?");

        // Quand l'utilisateur valide son adresse mail
        if(count($var) == 3 && $var[0] === 0)
        {
            $query->execute([1, 'valide', $var[2]]);
        }
        else
        {
            $varlength = count($var);
            $values = [];

            for ($i=0; $i < $varlength; $i++) { 
                array_push($values, $var[$i]);
            }

            $query->execute($values);
        }
    }



    // Retourne les articles
    public function findAllArticlesBy(int $id, string $as, string $join, string $where, ?string $limit = ""): array
    {
        $sql = "SELECT a.*, DATE_FORMAT(a.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, DATE_FORMAT(a.updated_at, 'le %d/%m/%Y à %H\h%i') as u_at, $as
        FROM articles A
        LEFT JOIN $join
        WHERE $where = ?
        ORDER BY a.created_at DESC";

        if($limit){
            $sql .= " LIMIT " . $limit;
        }

        $query = $this->pdo->prepare($sql);

        $query->execute([$id]);

        $articles = $query->fetchAll();

        return $articles;
    }

    // Afficher un article par son ID et l'ID de sa ville
    public function showArticleById(int $id_article, int $id_city): array
    {
        $query = $this->pdo->prepare("SELECT a.*, DATE_FORMAT(a.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, U.username
        FROM articles A
        LEFT JOIN users U ON U.id = A.id_user
        WHERE a.id = ? AND a.id_city = ?
        ORDER BY a.created_at DESC");

        $query->execute([$id_article, $id_city]);

        $article = $query->fetch();

        return $article;
    }

    // Trouver un article en recherchant le titre
    public function showAllArticlesByTitle(string $search): array
    {
        $query = $this->pdo->prepare('SELECT *
        FROM articles
        WHERE title
        LIKE ? ORDER BY id DESC');

        $query->execute(['%'. $search . '%']);

        $articles = $query->fetchAll();

        return $articles;        
    }

    // Afficher des fichiers par l'ID de l'article
    public function showFilesByArticleId(int $id_article): array
    {
        $query = $this->pdo->prepare("SELECT f.*
        FROM pictures F
        LEFT JOIN articles A ON A.id = F.id_post
        WHERE f.id_post = ?");

        $query->execute([$id_article]);

        $files = $query->fetchAll();

        return $files;
    }


    // Afficher commentaires par l'ID de l'article
    public function showAllComments(int $id): array
    {
        $query = $this->pdo->prepare("SELECT c.*, DATE_FORMAT(c.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, DATE_FORMAT(c.updated_at, 'le %d/%m/%Y à %H\h%i') as u_at, U.username
        FROM comments C
        LEFT JOIN users U ON U.id = C.id_user
        WHERE id_post = ?
        ORDER BY c.created_at DESC");

        $query->execute([$id]);

        $comments = $query->fetchAll();

        return $comments;
    }
}