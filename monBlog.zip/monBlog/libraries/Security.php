<?php 

/* Sécurité lié à si l'utilisateur est connecté ou pas */
class Security
{
    public static function isNotAuth()
    {
        if(!isset($_SESSION['auth'])){
            \Http::redirect('index.php?controller=User&task=login');
        }
    }

    public static function isAuth()
    {
        if(isset($_SESSION['auth'])){
            \Http::redirect('index.php?controller=City&task=index');
        }
    }
}