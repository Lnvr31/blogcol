<?php

namespace Controllers;

use Models\City;
use Models\Comments;

session_start();

class Article extends Controller
{
    protected $modelName = \Models\Articles::class;

    // Publication d'un article
    public function post()
    {
        \Security::isNotAuth();

        $error = null;

        // Récupération des villes pour pouvoir les afficher
        $cityModel = new City();
        $city = $cityModel->findAll();

        // Si le formulaire est envoyé
        if (isset($_POST['validate'])) {

            $title = htmlspecialchars($_POST['title']);
            $description = nl2br(htmlspecialchars($_POST['description']));
            $content = nl2br(htmlspecialchars($_POST['content']));
            date_default_timezone_set('Europe/paris');
            $date = date('Y-m-d H:i:s');
            $id_author = $_SESSION['id'];
            $pseudo = $_SESSION['name'];
            $id_city = $_POST['category'];

            // Si les champs ne sont pas vides
            if (!empty($title) && !empty($description) && !empty($content)) {

                if(strlen($title) <= 30) {

                    if(strlen($description) <= 30){
                        $id = $this->model->insert(
                            $var = [$title, $content, $date, $id_author, $description, $pseudo, $id_city],
                            '(title, content, created_at, id_user, description, pseudo_user, id_city) VALUES (?,?,?,?,?,?,?)'
                        );
        
                        \Http::redirect('index.php?controller=Article&task=showByUser');
                    } else {
                        $error = 'Votre description ne doit pas dépasser 30 caractères.';
                    }
                } else {
                    $error = 'Votre titre ne doit pas dépasser 30 caractères.';
                }

            } else {
                $error = 'Veuillez remplir tous les champs s\'il vous plaît';
            }
        }

        $pageTitle = "Publier un article";

        \Renderer::render('articles/addArticle', compact('pageTitle', 'error', 'city'));
    }

    // Affichage des articles selon la ville
    public function showByCity()
    {
        $id_city = htmlentities($_GET['id']);

        // Vérifier si l'id existe bien
        if (empty($id_city) || !ctype_digit($id_city) || !isset($id_city)) {
            \http::redirect('index.php?controller=City&task=index');
        } else {
            $articles = $this->model->findAllArticlesBy($id_city, 'U.username', 'users U ON U.id = A.id_user', 'a.id_city');

            $cityModel = new City();
            //$city = $cityModel->find($_GET['id'], 'id');
            $city = $cityModel->find('id', $id_city);
        }

        // Affichage
        $pageTitle = "Articles";

        \Renderer::render('articles/showByCity', compact('pageTitle', 'articles', 'city'));
    }

    // Afficher un article par son ID et l'ID de la ville, et l'espace commentaire
    public function show()
    {
        if (!empty($_GET['id']) && ctype_digit($_GET['id']) && !empty($_GET['id_city']) && ctype_digit($_GET['id_city']))
        {
            $id_article = htmlentities($_GET['id']);
            $id_city = htmlentities($_GET['id_city']);
        }

        if (!$id_article || !$id_article) {
            \Http::redirect('index.php?controller=City&task=index');
            // Alert js
        }


        $error = null;

        // Ajouter un commentaire
        $commentsModel = new Comments();

        // Si le formulaire est envoyé
        if (isset($_POST['validate'])) {

            $content = nl2br(htmlspecialchars($_POST['content']));
            date_default_timezone_set('Europe/paris');
            $date = date('Y-m-d H:i:s');
            $id_user = $_SESSION['id'];

            if (!empty($content) && strlen($content) < 200) {          

                $addComments = $commentsModel->insert(
                    $var = [$content, $id_user, $date, $id_article],
                        '(content, id_user, created_at, id_post) VALUES (?,?,?,?)'
                );

                \Http::redirect("index.php?controller=Article&task=show&id_city=$id_city&id=$id_article");
                // Alert js
            } else {
                $error = 'Votre commentaire ne doit pas être vide ni dépasser 200 caractères !';
            }
        }


        $article = $this->model->showArticleById($id_article, $id_city);

        $comments = $commentsModel->showAllComments($id_article);
        $numberOfComments = count($comments);

        // Affichage
        $pageTitle = $article['title'];

        \Renderer::render('articles/Article', compact('pageTitle', 'article', 'comments', 'error', 'numberOfComments', 'id_city'));
    }

    // Affichage articles selon l'utilisateur
    public function showByUser()
    {
        \Security::isNotAuth();

        $id = $_SESSION['id'];

        $articles = $this->model->findAllArticlesBy($id, 'C.city', 'city C ON C.id = A.id_city', 'a.id_user', 20);

        // Affichage
        $pageTitle = "Mes articles";

        \Renderer::render('articles/myArticles', compact('pageTitle', 'articles'));
    }

    // Modifier un article
    public function update()
    {   
        \Security::isNotAuth();
        
        $error = null;
        $article = null;
        $errorMsg = null;

        $id = $_GET['id'];

        // Si il y a bien un ID dans l'url
        if(isset($id) && !empty($id) && ctype_digit($id))
        {
            $get_id = htmlentities($_GET['id']);

            $article = $this->model->find('id', $get_id);
            
            // Si l'ID existe bien
            if($article !== false)
            {
                // Si l'article correspond à l'utilisateur connecté
                if( $article['id_user'] == $_SESSION['id'])
                {

                    // Si l'utilisateur valide le formulaire
                    if (isset($_POST['validate']))
                    {
                        $title = htmlspecialchars($_POST['title']);
                        $description = nl2br(htmlspecialchars($_POST['description']));
                        $content = nl2br(htmlspecialchars($_POST['content']));
                        date_default_timezone_set('Europe/paris');
                        $date = date('Y-m-d H:i:s');

                        // Si les champs sont tous remplis
                        if (!empty($title) && !empty($description) && !empty($content))
                        {   
                            $this->model->update([$title, $content, $description, $date, $get_id],
                            'title = ?, content = ?, description = ?, updated_at = ?', "id");

                            \Http::redirect('index.php?controller=Article&task=showByUser');
                        } else {
                            $errorMsg = 'Veuillez remplir tous les champs !';
                        }
                    }
                } else {
                    $error = "Vous n'êtes pas l'auteur de cet article";
                }
            } else {
                $error = 'Aucun article n\'à été trouver !';
            }
        } else {
            $error = 'Aucun article n\à été trouver !';
        }

        // Affichage
        $pageTitle = "Modifier mon article";

        \Renderer::render('articles/updateArticle', compact('pageTitle', 'article', 'error', 'errorMsg'));
    }


    // Suppression article
    public function delete()
    {   
        \Security::isNotAuth();

        if (!empty($_GET['id']) && ctype_digit($_GET['id']))
        {
            $get_id = htmlentities($_GET['id']);
    
            $article = $this->model->find('id', $get_id);
    
            // Vérification que l'utilisateur est bien l'auteur de l'article pour pouvoir le supprimer
            if($article['id_user'] == $_SESSION['id'])
            {
                $this->model->delete($get_id);
            } 
        }
        \Http::redirect('index.php?controller=Article&task=showByUser');
        //$this->showByUser();
    }
}
