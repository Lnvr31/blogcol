<?php

namespace Controllers;

// les Use

use Mail;
use Models\RecupPassword;
Use Security;
use SendMail;
use UserInfos;

session_start();


class User extends Controller
{
    protected $modelName = \Models\Users::class;


    // Inscription
    public function register()
    {
        \Security::isAuth();

        $error = null;

        if(isset($_POST['validate']))
        {
            $name = htmlspecialchars(($_POST['name']));
            $mail = htmlspecialchars(($_POST['mail']));
            $password = htmlspecialchars(($_POST['password']));
            $password2 = htmlspecialchars(($_POST['password2']));
            $avatar = 'default.jpg';

            if (!empty($name) && !empty($mail) && !empty($password) && !empty($password2))
            {
                $verifName = \UserInfos::name($name);
                $verifMail = \UserInfos::mail($mail);
                $verifPassword = \UserInfos::password($password, $password2);

                if ($verifName !== true) {
                    $error = $verifName;
                }

                else if ($verifMail !== true) {
                    $error = $verifMail;
                }

                else if ($verifPassword !== true) {
                    $error = $verifPassword;
                }
                // Si tous les critères sont respectés
                else
                {
                    $password = password_hash($password, PASSWORD_DEFAULT);

                    function token_random_string($leng = 20): string
                    {
                        $str = '0123456789azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN';
                        $token = '';
                        for ($i = 0; $i < $leng; $i++) {
                            $token .= $str[rand(0, strlen($str) - 1)];
                        }
                        return $token;
                    }

                    $token = token_random_string(20);

                    $id = $this->model->insert(
                        $var = [$name, $mail, $password, $token],
                        '(username, mail, password, token) VALUES (?,?,?,?)'
                    );

                    $_SESSION['id'] = $id;
                    $_SESSION['name'] = $name;
                    $_SESSION['mail'] = $mail;
                    $_SESSION['password'] = $password;

                    // Si l'utilisateur souhaite mettre une photo de profil
                    if(isset($_FILES['avatar']) && !empty($_FILES['avatar']['name']))
                    {
                        $verifAvatar = \FilesInfos::avatar(2100000);

                        if ($verifAvatar[0] === true)
                        {
                            $avatar = $verifAvatar[1];
                            $this->model->update([$avatar , $mail], 'avatar = ?', "mail");
                        } else
                        {
                            $error = $verifAvatar;
                        }      
                    }

                    $subject = 'Confirmation d\'email';
                    $body = "Pour confirmer votre inscription, veuillez cliquer sur ce lien :

                    <a href='http://localhost/monBlog/index.php?controller=User&task=mailVerif&mail=$mail&token=$token'>Confirmez votre adresse mail !</a>";

                    $error = \Mail::sendMail($mail, $subject, $body);

                    if(!$error)
                    {
                        \Http::redirect('index.php?controller=City&task=index');
                        // Javascript Alert
                    } else {
                        echo $error;
                    }
                }
            }
            // Si tous les champs ne sont pas remplis
            else
            {
                $error =  'Veuillez remplir tous les champs s\'il vous plaît !';
            }
        }

        // Affichage
        $pageTitle = "Inscription";

        \Renderer::render('articles/register', compact('pageTitle', 'error'));
    }

    // Validation de l'adresse mail
    public function mailVerif()
    {   
        if($_GET){
            if($_GET['mail']){
                $mail = htmlspecialchars($_GET['mail']);
            }
        
            if($_GET['token']){
                $token = htmlspecialchars($_GET['token']);
            }
        
            if(!empty($mail) && !empty($token))
            {
                $mailExist = $this->model->find('mail', $mail);
                $tokenExist = $this->model->find('token', $token);
   
                if($mailExist && $tokenExist){

                    $this->model->update([0, $token, $mail], 'validation = ?, token = ?', "mail");
                    
                    $_SESSION['auth'] = true;

                    echo "<script type=\"text/javascript\">
                    alert('Votre adresse mail est bien confirmé !');
                    document.location.href='index.php?controller=City&task=index';
                    </script>";   
                }
            }
        }

    }

    // Connexion
    public function login()
    {   
        \Security::isAuth();

        $error = null;

        if (isset($_POST['validate'])) {

            if (!empty($_POST['name']) && !empty($_POST['password']))
            {
                $user_pseudo = htmlspecialchars(($_POST['name']));
                $user_password = htmlspecialchars(($_POST['password']));
                $userInfos = $this->model->find('username', $user_pseudo);

                // si l'utilisateur existe bien
                if ($userInfos !== false)
                {
                    // Si toutes les vérifications sont faites
                    if (password_verify($user_password, $userInfos['password']))
                    {
                        if ($userInfos['validation'] == 1)
                        {
                            // session start
                            $_SESSION['auth'] = true;
                            $_SESSION['id'] = $userInfos['id'];
                            $_SESSION['name'] = $userInfos['username'];
                            $_SESSION['mail'] = $userInfos['mail'];
                            $_SESSION['password'] = $userInfos['password'];

                            if(isset($_POST['remindme'])){
                                setcookie("name", $user_pseudo);
                                setcookie("password", $user_password);
                            } else {
                                if(isset($_COOKIE['name'])){
                                    setcookie("name");
                                }
                                if(isset($_COOKIE['password'])){
                                    setcookie("password");
                                }
                            }

                            \Http::redirect('index.php?controller=City&task=index');

                        } else {
                            $error = 'Veuillez confirmer votre compte en cliquant sur le lien envoyé sur votre adresse mail ';
                        }

                    } else {
                        $error = 'Votre mot de passe est incorrect !';
                    }

                } else {
                    $error = 'Votre pseudo n\'existe pas ...';
                }
            }
            else
            {
                $error = 'Veuillez remplir tous les champs s\'il vous plaît !';
            }
        }

        // Affichage
        $pageTitle = "Connexion";

        \Renderer::render('articles/login', compact('pageTitle', 'error'));
    }

    // Déconnection
    public function logout()
    {
        \Security::isNotAuth();

        $_SESSION = [];
        session_destroy();
        \Http::redirect('index.php?controller=City&task=index');
    }

    // Mot de passe oublié
    public function passwordForget()
    {
        \Security::isAuth();

        $error = null;

        if (isset($_POST['validate']))
        {
            if (empty($_POST['mail']) || !filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
                $error = 'Veuillez rentrer votre adresse email !';
            } else {
                $mail = htmlspecialchars($_POST['mail']);

                $userInfos = $this->model->find('mail', $mail);

                // si le mail existe bien
                if ($userInfos !== false) 
                {
                    //Si l'utilisateur à bien validé son compte
                    if ($userInfos['validation'] == 1)
                    {
                        function token_random_string($leng = 20)
                        {
                            $str = '0123456789azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN';
                            $token = '';
                            for ($i = 0; $i < $leng; $i++) {
                                $token .= $str[rand(0, strlen($str) - 1)];
                            }
                            return $token;
                        }

                        $token = token_random_string(20);

                        $recupPasswordModel = new RecupPassword();

                        $userExist = $recupPasswordModel->find('mail', $mail);
                        
                        if ($userInfos == false)
                        {
                            $recupPasswordModel->insert(
                                $var = [$mail, $token],
                                '(mail, token) VALUES (?,?)'
                            );
                        } else {
                            $recupPasswordModel->update(
                                [$token , $mail], 'token = ?', "mail"
                            );
                        }

                        $subject = 'Réinitialisation du mot de passe';
                        $body = 'Pour réinitialiser votre mot de passe, veuillez cliquer sur ce lien:

                        <a href="http://localhost/monBlog/index.php?controller=User&task=newPassword&mail=' . $mail . '&token=' . $token . ' ">Réinitialisation</a>';

                        $error = \Mail::sendMail($mail, $subject, $body);

                        if(empty($error))
                        {
                            \Http::redirect('index.php?controller=City&task=index');
                            // Javascript Alert
                        }

                    } else {
                        $error = 'Veuillez confirmer votre compte en cliquant sur le lien envoyé sur votre adresse mail ';
                    }
                } else {
                    $error = "L'adresse email saisi ne correspond à aucun membre";
                }              
            }
        }
        $pageTitle = "Mot de passe oublié";

        \Renderer::render('articles/passwordForget', compact('pageTitle', 'error'));
    }

    // Nouveau mot de passe
    public function newPassword()
    {
        \Security::isAuth();

        $error = null;

        if($_GET){

            if($_GET['mail']){
                $mail = htmlspecialchars($_GET['mail']);
            }
        
            if($_GET['token']){
                $token = htmlspecialchars($_GET['token']);
            }

            if(!empty($mail) && !empty($token))
            {
                $userInfos = $this->model->find('mail', $mail);
                $tokenExist = $this->model->find('token', $token);

                // si le mail et le token existe bien
                if ($userInfos !== false && $tokenExist !== false)
                {
                    if(isset($_POST['validate']))
                    {
                        $password = htmlspecialchars(($_POST['password']));
                        $password2 = htmlspecialchars(($_POST['password2']));

                        if (!empty($password) && !empty($password2))
                        {
                            $verifPassword = \UserInfos::password($password, $password2);

                            if ($verifPassword === true)
                            {
                                $password = password_hash($password, PASSWORD_DEFAULT);

                                $this->model->update([$password, $mail], 'password = ?', "mail");

                                $_COOKIE['password'] = $password;
                                $_SESSION['password'] = $password;

                                echo "<script type=\"text/javascript\">
                                alert('Votre mot de passe à bien été modifié !');
                                document.location.href='index.php?controller=User&task=login';
                                </script>"; 

                            } else {
                                $error = $verifPassword;                          
                            }
                        } else {
                            $error =  'Veuillez remplir tous les champs s\'il vous plaît !';
                        }
                    }
                } else {
                    \Http::redirect('index.php?controller=User&task=register');
                }            
            }
        }    

        $pageTitle = "Nouveau mot de passe";

        \Renderer::render('articles/newPassword', compact('pageTitle', 'error'));
    }
}