<?php

// Renvoie la vue d'une page
class Renderer
{
    public static function render(string $path, array $var = [])
    {
        extract($var);

        ob_start();
        require('templates/' . $path . '.phtml');
        $pageContent = ob_get_clean();

        require('templates/layout.phtml');
    }
}