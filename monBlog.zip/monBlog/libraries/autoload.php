<?php

// Ce fichier sert à charger automatiquement les fichiers requis
spl_autoload_register(function($className){
    if($className == "PHPMailer\PHPMailer\PHPMailer"){
        $className = 'PHPMailer';
        require_once("libraries/PHPMailer/$className.php");

    } else if($className == 'PHPMailer\PHPMailer\SMTP') {
        $className = 'SMTP';
        require_once("libraries/PHPMailer/$className.php");

    } else if ($className == 'PHPMailer\PHPMailer\Exception') {
        $className = 'Exception';
        require_once("libraries/PHPMailer/$className.php");

    } else {
        $className = str_replace("\\", "/", $className);
    
        require_once("libraries/$className.php");
    }

});