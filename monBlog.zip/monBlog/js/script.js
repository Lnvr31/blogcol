window.onload = () => {

    // Cursor
    let mouseCursor = document.querySelector(".cursor");
    window.addEventListener('mousemove', cursor);

    function cursor(e) {
        mouseCursor.style.top = e.pageY + 'px';
        mouseCursor.style.left = e.pageX + 'px';
    }

    // Cursor growing
    let navLinks = document.querySelectorAll(".navbar a");
    navLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            mouseCursor.classList.add("link-grow");
            link.classList.add("hovered-link");
        });

        link.addEventListener('mouseleave', () => {
            mouseCursor.classList.remove("link-grow");
            link.classList.remove("hovered-link");
        });
    })


    // Toggle
    let toggle = document.querySelector('.toggle');
    let body = document.querySelector('body');

    toggle.addEventListener('click', function() {
        body.classList.toggle('open')
    })


    // Carrousel
    let compteur = 0;
    let timer, elements, slides, slideWidth;

    const diapo = document.querySelector(".diapo");

    elements = document.querySelector(".elements");

    let firstImage = elements.firstElementChild.cloneNode(true);

    elements.appendChild(firstImage);

    slides = Array.from(elements.children);

    slideWidth = diapo.getBoundingClientRect().width;

    let next = document.querySelector("#prev");
    let prev = document.querySelector("#next");

    timer = setInterval(slideNext, 4000);

    diapo.addEventListener("mouseover", stopTimer);
    diapo.addEventListener("mouseout", startTimer);

    next.addEventListener("click", slideNext);
    prev.addEventListener("click", slidePrev);
    

    function slideNext(){
        compteur++;
        elements.style.transition = "1s linear";

        let decal = -slideWidth * compteur;
        elements.style.transform = `translateX(${decal}px)`;

        setTimeout(function(){
            if(compteur >= slides.length - 1){
                compteur = 0;
                elements.style.transition = "unset";
                elements.style.transform = "translateX(0)";
            }
        }, 1000);
    }

    function slidePrev(){
        compteur--;
        elements.style.transition = "1s linear";
        
        if(compteur < 0){
            compteur = slides.length - 1;
            let decal = -slideWidth * compteur;
    
            elements.style.transition = "unset";
            elements.style.transform = `translateX(${decal}px`;
            setTimeout(slidePrev, 1);
        }

        let decal = -slideWidth * compteur;
        elements.style.transform = `translateX(${decal}px`;
    }

    function stopTimer(){
        clearInterval(timer);
    }

    function startTimer(){
        timer = setInterval(slideNext, 4000);
    }


    // Scroll effet
    let navbar = document.querySelector(".navbar ul");

    navbar.style.padding = "40px";

    window.addEventListener("scroll", () => {
        if(window.scrollY > 50) {
            navbar.style.padding = "20px";
        } else {
            navbar.style.padding = "40px";
        }
    })
}