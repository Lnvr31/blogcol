<?php

// Ce fichier est tout le temps appelé et va appeler un controller et une tâche

require('libraries/autoload.php');
\Application::process();