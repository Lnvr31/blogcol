<?php

class Renderer
{
    // Renvoie la vue d'une page

    public static function render(string $path, array $variables = [])
    {
        extract($variables);

        ob_start();
        require('templates/' . $path . '.phtml');
        $pageContent = ob_get_clean();

        require('templates/head.phtml');
    }
}
