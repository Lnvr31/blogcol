<?php 

/* Connexion à la base de données */

class Database
{
    public static function getPdo(): PDO
    {
        $pdo = new PDO(
            'mysql:host=localhost;
            dbname=blog_voyages;
            charset=utf8',
            'root', '',
            [
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

        return $pdo;    
    }
}