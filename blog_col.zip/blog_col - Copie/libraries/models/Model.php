<?php

namespace Models;


abstract class Model
{
    protected $pdo;
    protected $table;

    // Connexion à la base de données
    public function __construct()
    {
        $this->pdo = \Database::getPdo();
    }


    
    /* Récupérer les infos grâce à son identifiant */
    public function find($info, $filter)
    {
        $query = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE $filter = ?");
        $query->execute([
            $info
        ]);
        $item = $query->fetch();
        return $item;
    }


    // Retourne tous les éléments
    public function findAll($order = "")
    {
        $sql = "SELECT * FROM {$this->table}";
        if ($order) {
            $sql .= " ORDER BY " . $order;
        }
        $results = $this->pdo->query($sql);

        $items = $results->fetchAll();

        return $items;
    }


    // Supprimer un élément
    public function delete($id): void
    {
        $query = $this->pdo->prepare("DELETE FROM {$this->table} WHERE id = ?");
        $query->execute([$id]);
    }
}
