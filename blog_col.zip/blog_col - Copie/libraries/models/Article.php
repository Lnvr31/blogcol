<?php

namespace Models;

class Article extends Model
{
    protected $table = "articles";


    // Insérer un article
    public function insertArticle($title, $description, $content, $id_author, $pseudo, $date, $id_city)
    {
        $query = $this->pdo->prepare(
            '
            INSERT INTO articles (title, description, content, id_user, pseudo_user, created_at, id_city)
            VALUES (?, ?, ?, ?, ?, ?, ?)'
        );

        $query->execute([
            $title,
            $description,
            $content,
            $id_author,
            $pseudo,
            $date,
            $id_city
        ]);

        $id_article = $this->pdo->lastInsertId();

        return $id_article;
    }


    public function insertPictures($filename, $id_article, $file): void
    {
        $query = $this->pdo->prepare(
            '
            INSERT INTO pictures (name, id_post, file) VALUES(?, ?, ?)'
        );

        $query->execute(array($filename, $id_article, $file));
    }


    // Afficher articles par ville
    public function showArticleByCity($id)
    {
        $query = $this->pdo->prepare("SELECT a.*, DATE_FORMAT(a.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, U.username
        FROM articles A
        LEFT JOIN users U ON U.id = A.id_user
        WHERE a.id_city = ?
        ORDER BY a.created_at DESC");

        $query->execute([$id]);

        $articles = $query->fetchAll();

        return $articles;
    }


    // Afficher articles par ville
    public function showArticleByUser($id, $limit)
    {
        $query = $this->pdo->prepare("SELECT a.*, DATE_FORMAT(a.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, C.city
        FROM articles A
        LEFT JOIN city C ON C.id = A.id_city
        WHERE a.id_user = ?
        ORDER BY a.created_at DESC
        LIMIT $limit");

        $query->execute([$id]);

        $articles = $query->fetchAll();

        return $articles;
    }


    // Afficher un article par son ID et l'ID de sa ville
    public function showArticle($id_article, $id_city)
    {
        $query = $this->pdo->prepare("SELECT a.*, DATE_FORMAT(a.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, U.username
        FROM articles A
        LEFT JOIN users U ON U.id = A.id_user
        WHERE a.id = ? AND a.id_city = ?
        ORDER BY a.created_at DESC");

        $query->execute([$id_article, $id_city]);

        $article = $query->fetch();

        return $article;
    }


    // Afficher des fichiers par l'ID de l'article
    public function showFilesByArticle($id_article)
    {
        $query = $this->pdo->prepare("SELECT f.*
        FROM pictures F
        LEFT JOIN articles A ON A.id = F.id_post
        WHERE f.id_post = ?");

        $query->execute([$id_article]);

        $files = $query->fetchAll();

        return $files;
    }


    // Modifier 
    public function update($title, $description, $content, $id)
    {
        $query = $this->pdo->prepare("UPDATE articles SET title = ?, description = ?, content = ? 
        WHERE id = ?");

        $query->execute([$title, $description, $content, $id]);
    }


    // Trouver un article en recherchant le titre
    public function showByTitle($search)
    {
        $query = $this->pdo->prepare('SELECT *
        FROM articles
        WHERE title
        LIKE "%'.$search.'%" ORDER BY id DESC');

        $query->execute([$search]);

        $articles = $query->fetchAll();

        return $articles;        
    }
}
