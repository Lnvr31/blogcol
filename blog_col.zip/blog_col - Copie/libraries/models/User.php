<?php

namespace Models;

class User extends Model
{
    protected $table = "users";


    // Insérer un utilisateur dans la base de données
    public function insertUser($name, $mail, $password, $avatar): void
    {   
        $query = $this->pdo->prepare('INSERT INTO users (username, mail, password, avatar) VALUES (?, ?, ?, ?)');
        
        $password = password_hash($password, PASSWORD_DEFAULT);

        $query->execute([
            $name,
            $mail,
            $password,
            $avatar
        ]);
        
        $_SESSION['id'] = $this->pdo->lastInsertId();
        $_SESSION['auth'] = true;
        $_SESSION['name'] = $name;
        $_SESSION['mail'] = $mail;
        $_SESSION['password'] = $password;
    }
}