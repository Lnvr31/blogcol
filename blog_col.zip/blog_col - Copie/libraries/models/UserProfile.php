<?php

namespace Models;

class UserProfile extends Model
{
    protected $table = "users";

    public function update($name, $mail, $id)
    {
        $query = $this->pdo->prepare("UPDATE users SET username = ?, mail = ? 
        WHERE id = ?");

        $query->execute([$name, $mail, $id]);
    }

    public function updatePassword($password, $id)
    {
        $query = $this->pdo->prepare("UPDATE users SET password = ? 
        WHERE id = ?");

        $password = password_hash($password, PASSWORD_DEFAULT);

        $query->execute([$password, $id]);
    }

    public function updateAvatar($avatar, $id)
    {
        $query = $this->pdo->prepare("UPDATE users SET avatar = ? 
        WHERE id = ?");

        $query->execute([$avatar, $id]);
    }
}