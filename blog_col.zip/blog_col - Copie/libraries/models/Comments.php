<?php

namespace Models;

class Comments extends Model
{
    protected $table = "comments";

    // Afficher commentaires par l'ID de l'article
    public function showComments($id)
    {
        $query = $this->pdo->prepare("SELECT c.*, DATE_FORMAT(c.created_at, 'le %d/%m/%Y à %H\h%i') as c_at, U.username
        FROM comments C
        LEFT JOIN users U ON U.id = C.id_user
        WHERE id_post = ?
        ORDER BY c.created_at DESC");

        $query->execute([$id]);

        $comments = $query->fetchAll();

        return $comments;
    }


    // Insérer un commentaire
    public function insertComment($content, $pseudo, $date, $id_post): void
    {   
        $query = $this->pdo->prepare('
            INSERT INTO comments (content, id_user, created_at, id_post)
            VALUES (?, ?, ?, ?)'
        );

        $query->execute([
            $content,
            $pseudo,
            $date,
            $id_post
        ]);
    }
}