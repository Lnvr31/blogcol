<?php

namespace Controllers;

session_start();

class Comments extends Controller
{
    protected $modelName = "\Models\Comments";

    // Affiche les commentaires
    public function show()
    {
        $get_id = htmlentities($_GET['id']);

        $comments = $this->model->showComments($get_id);

        // Affichage
        \Renderer::render('articles/Article', compact('comments'));
    }
}