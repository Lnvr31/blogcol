<?php

namespace Controllers;

use Models\Comments;
use Security;

session_start();

class MyArticle extends Controller
{
    protected $modelName = "\Models\Article";

    // Affichage articles selon l'utilisateur
    public function showByUser()
    {
        \Security::isNotAuth();

        $id = $_SESSION['id'];

        $articles = $this->model->showArticleByUser($id, 20);

        // Affichage
        $pageTitle = "Mes articles";

        \Renderer::render('articles/myArticles', compact('pageTitle', 'articles'));
    }


    // Modifier un article
    public function update()
    {
        \Security::isNotAuth();

        $error = null;
        $article = null;
        $errorMsg = null;
        

        // Si il y a bien un ID dans l'url
        if(isset($_GET['id']) && !empty($_GET['id']))
        {
            $get_id = htmlentities($_GET['id']);

            $article = $this->model->find($get_id, 'id');
            
            // Si l'ID existe bien
            if($article !== false)
            {
                // Si l'article correspond à l'utilisateur connecté
                if( $article['id_user'] === $_SESSION['id'])
                {

                    // Si l'utilisateur valide le formulaire
                    if (isset($_POST['validate']))
                    {
                        $title = htmlspecialchars($_POST['title']);
                        $description = nl2br(htmlspecialchars($_POST['description']));
                        $content = nl2br(htmlspecialchars($_POST['content']));

                        // Si les champs sont tous remplis
                        if (!empty($title) && !empty($description) && !empty($content))
                        {
                            $this->model->update($title, $description, $content, $get_id);
                            \Http::redirect('index.php?controller=Article&task=showByUser');
                        } else {
                            $errorMsg = 'Veuillez remplir tous les champs !';
                        }
                    }
                } else {
                    $error = "Vous n'êtes pas l'auteur de cet article";
                }
            } else {
                $error = 'Aucun article à été trouver !';
            }
        } else {
            $error = 'Aucun article à été trouver !';
        }

        // Affichage
        $pageTitle = "Modifier mon article";

        \Renderer::render('articles/updateArticle', compact('pageTitle', 'article', 'error', 'errorMsg'));
    }


    // Suppression article
    public function delete()
    {
        \Security::isNotAuth();

        $get_id = htmlentities($_GET['id']);

        $article = $this->model->find($get_id, 'id');

        // Vérification que l'utilisateur est bien l'auteur de l'article pour pouvoir le supprimer
        if($article['id_user'] === $_SESSION['id']){
            $this->model->delete($get_id);
        } 

        $this->showByUser();
    }
}