<?php

namespace Controllers;

use Http;
use Models\Article;
use Security;
use UserInfos;
use FilesInfos;

session_start();

class UserProfile extends Controller
{
    protected $modelName = "\Models\UserProfile";

    public function showMyProfile()
    {
        \Security::isNotAuth();

        $user = $this->model->find($_SESSION['id'], 'id');

        $articleModel = new Article();
        $lastArticles = $articleModel->showArticleByUser($_SESSION['id'], 3);
        $articles = $articleModel->showArticleByUser($_SESSION['id'], 100);
        $numberOfArticles = count($articles);

        // Affichage
        $pageTitle = "Mon profil";

        \Renderer::render('articles/UserProfile', compact('pageTitle', 'user', 'lastArticles', 'articles', 'numberOfArticles'));
    }


    public function editMyProfile()
    {
        \Security::isNotAuth();

        $id = htmlentities($_GET['id']);
        $error = null;
        $error2 = null;
        $avatar = null;

        //  Vérification du GET['id']
        if (isset($id) && !empty($id)) {
            if ($id == $_SESSION['id']) {
                $user = $this->model->find($id, 'id');
            } else {
                \Http::redirect('index.php?controller=City&task=index');
            }
        } else {
            \Http::redirect('index.php?controller=City&task=index');
        }


        // Si l'utilisateur valide le formulaire
        if (isset($_POST['validate'])) {

            $name = htmlspecialchars(($_POST['name']));
            $mail = htmlspecialchars(($_POST['mail']));
            $password = htmlspecialchars(($_POST['password']));
            $password2 = htmlspecialchars(($_POST['password2']));

            // Vérification nom et mail
            if (!empty($name) && !empty($mail)) {
                $verifName = \UserInfos::name($name);
                $verifMail = \UserInfos::mail($mail);

                //Si l'utilisateur change son nom
                if ($name !== $_SESSION['name']) {
                    if ($verifName !== true) {
                        $error = $verifName;
                    } else {
                        //Si l'utilisateur change aussi son mail
                        if ($mail !== $_SESSION['mail']) {
                            if ($verifMail !== true) {
                                $error = $verifMail;
                            } else {

                                echo 'success';
                                $this->model->update($name, $mail, $id);
                                $_SESSION['name'] = $name;
                                $_SESSION['mail'] = $mail;
                                \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                            }
                        }
                    }
                }
                // L'utilisateur change pas son nom 
                else {
                    // L'utilisateur change que son mail
                    if ($mail !== $_SESSION['mail']) {
                        if ($verifMail !== true) {
                            $error = $verifMail;
                        } else {
                            $this->model->update($name, $mail, $id);
                            $_SESSION['name'] = $name;
                            $_SESSION['mail'] = $mail;
                            \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                        }
                    }
                    // Si l'utilisateur n'a changer aucune information dans le formulaire
                    else {
                        if (empty($password) && empty($password2) && !isset($_FILES['avatar']))
                            \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                    }
                }
            } else {
                $error = 'Veuillez remplir les champs du pseudo et de l\'adresse mail !';
            }


            // Vérification mot de passe
            if (!empty($password)) {
                // Si l'utilisateur à rentrer les 2 mots de passe
                if (!empty($password2)) {
                    $verifPassword = \UserInfos::password($password, $password2);

                    if ($verifPassword !== true) {
                        $error2 = $verifPassword;
                    } else {
                        $this->model->updatePassword($password, $id);
                        \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                    }
                }
                // Si l'utilisateur à rentrer que le 1er mot de passe
                else {
                    $error2 = 'Vous devez confirmés votre mot de passe !';
                }
            } else {
                // Si l'utilisateur à rentrer que le 2eme mot de passe
                if (!empty($password2)) {
                    $error2 = 'Vous devez rentrez un mot de passe pour pouvoir le confirmé !';
                }
            }


            if(isset($_FILES['avatar']) && !empty($_FILES['avatar']['name']))
            {
                $verifAvatar = \FilesInfos::avatar(2100000);

                if ($verifAvatar[0] === true) {
                    $avatar = $verifAvatar[1];
                    $this->model->updateAvatar($avatar, $_SESSION['id']);
                    \Http::redirect('index.php?controller=UserProfile&task=showMyProfile');
                } else {
                    $error = $verifAvatar;
                }     
            }
        }


        // Affichage
        $pageTitle = "Modifier mon profil";

        \Renderer::render('articles/editProfile', compact('pageTitle', 'avatar', 'error', 'error2', 'user'));
    }
}
