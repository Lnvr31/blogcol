<?php

namespace Controllers;

use Models\City;
use Models\Comments;
use Security;
use Http;
use FilesInfos;

session_start();

class Article extends Controller
{
    protected $modelName = "\Models\Article";

    // Publication d'un article
    public function post()
    {
        $error = null;

        // Récupération des villes pour pouvoir les afficher
        $cityModel = new City();
        $city = $cityModel->findAll();

        // Si le formulaire est envoyé
        if (isset($_POST['validate'])) {

            $title = htmlspecialchars($_POST['title']);
            $description = nl2br(htmlspecialchars($_POST['description']));
            $content = nl2br(htmlspecialchars($_POST['content']));
            date_default_timezone_set('Europe/paris');
            $date = date('Y-m-d H:i:s');
            $id_author = $_SESSION['id'];
            $pseudo = $_SESSION['name'];
            $id_city = $_POST['category'];

            // Si les champs ne sont pas vides
            if (!empty($title) && !empty($description) && !empty($content)) {

                // Si l'utilisateur veut mettre des photos dans son article 
                if (isset($_FILES['pictures']) && !empty($_FILES['pictures']['name'][0])) {
                    
                    $countfiles = count($_FILES['pictures']['name']);
                    $extensions = ['jpg', 'png', 'gif', 'jpeg'];
                    
                    $verifFiles = \FilesInfos::file($countfiles, $extensions);

                    // Si le format du fichier est respecté
                    if ($verifFiles[0] === true)
                    {
                        $id_article = $this->model->insertArticle($title, $description, $content, $id_author, $pseudo, $date, $id_city);

                        for ($i = 0; $i < $countfiles; $i++) {
                            $extensionUpload = $verifFiles[1];
                            $name = $_SESSION['id'] . '-' . $id_article . '(' . $i . ').' . $extensionUpload;
                            $target_file = "libraries/members/pictures/" . $name;
                            $file = move_uploaded_file($_FILES['pictures']['tmp_name'][$i], $target_file);
                            $this->model->insertPictures($name, $id_article, $file);
                        }

                        //\Http::redirect('index.php?controller=City&task=index');

                    } else {
                        $error = $verifFiles;
                    }

                // Si l'utilisateur veut poster un article sans mettre de photos   
                } else {
                    echo 'Il n y a pas de photos';
                    $this->model->insertArticle($title, $description, $content, $id_author, $pseudo, $date, $id_city);
                    \Http::redirect('index.php?controller=MyArticle&task=showByUser');
                }
            } else {
                $error = 'Veuillez remplir tous les champs s\'il vous plaît';
            }
        }

        $pageTitle = "Publier un article";

        \Renderer::render('articles/addArticle', compact('pageTitle', 'error', 'city'));
    }


    // Affichage des articles selon la ville
    public function showByCity()
    {

        $get_id = htmlentities($_GET['id']);

        // Chercher pour vérifier si l'id existe bien
        if (empty($get_id) || $get_id <= 0 || !isset($get_id)) {
            \http::redirect('index.php?controller=City&task=index');
        }

        $articles = $this->model->showArticleByCity($get_id);
        
        $cityModel = new City();
        $city = $cityModel->find($_GET['id'], 'id');

        // Affichage
        $pageTitle = "Articles";

        \Renderer::render('articles/showByCity', compact('pageTitle', 'articles', 'city'));
    }


    // Afficher un article par son ID et l'ID de la ville, et l'espace commentaire
    public function show()
    {

        $id_article = htmlentities($_GET['id']);
        $id_city = htmlentities($_GET['id_city']);

        $error = null;

        // Ajouter un commentaire
        $commentsModel = new Comments();

        // Si le formulaire est envoyé
        if (isset($_POST['validate'])) {

            $content = nl2br(htmlspecialchars($_POST['content']));
            $date = date('Y-m-d H:i:s');
            $pseudo = $_SESSION['id'];

            if (!empty($content) && strlen($content) < 200) {

                $addComments = $commentsModel->insertComment($content, $pseudo, $date, $id_article);
                \Http::redirect('index.php?controller=City&task=index');
            } else {
                $error = 'Votre commentaire ne doit pas être vide ni dépasser 200 caractères !';
            }
        }



        $article = $this->model->showArticle($id_article, $id_city);
        $files = $this->model->showFilesByArticle($id_article);

        $comments = $commentsModel->showComments($id_article);
        $numberOfComments = count($comments);

        // Affichage
        $pageTitle = $article['title'];

        \Renderer::render('articles/Article', compact('pageTitle', 'article', 'files', 'comments', 'error', 'numberOfComments'));
    }
}
