<?php

namespace Controllers;

use Models\article;

session_start();

class City extends Controller
{
    protected $modelName = "\Models\City";

    // Affichage de toutes les villes sur la page d'accueil
    public function index(){

        $city = $this->model->findAll();
        
        $articles = null;

        if(isset($_GET['search']) && !empty($_GET['search'])){

            $search = ($_GET['search']);

            $articleModel = new Article();
            $articles = $articleModel->showByTitle($search);
        }

        $pageTitle = "Accueil";
    
        \Renderer::render('articles/index', compact('pageTitle', 'city', 'articles'));
    }
}