<?php

namespace Controllers;

use Http;
use Security;
use Database;
use UserInfos;
use FilesInfos;

session_start();

class User extends Controller
{
    protected $modelName = "\Models\User";

    // Inscription
    public function register()
    {   
        \Security::isAuth();

        $error = null;

        if(isset($_POST['validate'])) {

            $name = htmlspecialchars(($_POST['name']));
            $mail = htmlspecialchars(($_POST['mail']));
            $password = htmlspecialchars(($_POST['password']));
            $password2 = htmlspecialchars(($_POST['password2']));
            $avatar = 'default.jpg';

            // Si tous les champs sont remplis
            if (!empty($name) && !empty($mail) && !empty($password) && !empty($password2)) {

                $verifName = \UserInfos::name($name);
                $verifMail = \UserInfos::mail($mail);
                $verifPassword = \UserInfos::password($password, $password2);
                

                if ($verifName !== true) {
                    $error = $verifName;
                }

                else if ($verifMail !== true) {
                    $error = $verifMail;
                }

                else if ($verifPassword !== true) {
                    $error = $verifPassword;

                // Si tous les critéres sont respectés    
                } else {

                    // Si l'utilisateur met une photo de profil
                    if(isset($_FILES['avatar']) && !empty($_FILES['avatar']['name']))
                    {
                        $verifAvatar = \FilesInfos::avatar(2100000);

                        if ($verifAvatar === true) {
                            
                            $avatar = $verifAvatar[1];
                            $this->model->insertUser($name, $mail, $password, $avatar);
                            \Http::redirect('index.php?controller=City&task=index');
                        } else {
                            $error = $verifAvatar;
                        }     
                    // Si l'utilisateur veut s'inscrire sans mettre de photo de profil    
                    } else {    
                        $this->model->insertUser($name, $mail, $password, $avatar);
                        \Http::redirect('index.php?controller=City&task=index');
                    }
                }
            
            // Si tous les champs n'ont pas été remplis
            } else {
                $error =  'Veuillez remplir tous les champs s\'il vous plaît !';
            }
        }

        // Affichage
        $pageTitle = "Inscription";

        \Renderer::render('articles/register', compact('pageTitle', 'error'));
    }



    // Connexion
    public function login()
    {   
        \Security::isAuth();

        $error = null;

        if (isset($_POST['validate'])) {

            if (!empty($_POST['name']) && !empty($_POST['password'])) {

                $user_pseudo = htmlspecialchars(($_POST['name']));
                $user_password = htmlspecialchars(($_POST['password']));
                $userInfos = $this->model->find($user_pseudo, 'username');

                // si l'utilisateur existe bien
                if ($userInfos !== false) {

                    // Si toutes les vérifications sont faites
                    if (password_verify($user_password, $userInfos['password'])) {

                        $_SESSION['auth'] = true;
                        $_SESSION['id'] = $userInfos['id'];
                        $_SESSION['name'] = $userInfos['username'];
                        $_SESSION['mail'] = $userInfos['mail'];

                        \Http::redirect('index.php?controller=City&task=index');

                    } else {
                        $error = 'Votre mot de passe est incorrect !';
                    }
                } else {
                    $error = 'Votre pseudo n\'existe pas ...';
                }
            } else {
                $error = 'Veuillez remplir tous les champs s\'il vous plaît !';
            }
        }

        // Affichage
        $pageTitle = "Connexion";

        \Renderer::render('articles/login', compact('pageTitle', 'error'));
    }


    // Déconnection
    public function logout()
    {
        \Security::isNotAuth();

        session_start();
        $_SESSION = [];
        session_destroy();
        \Http::redirect('index.php?controller=City&task=index');
    }
}