<?php

class Http {
    // Redirection

    // redirect('index.php')
    public static function redirect(string $url): void
    {
        header("Location: $url");
        exit();
    }
}