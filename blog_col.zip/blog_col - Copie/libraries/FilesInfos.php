<?php

/* Vérifications des fichiers rentrées par l'utilisateur */
class FilesInfos
{
    public static function avatar($size)
    {
        $maxSize = $size;
        $extensions = ['jpg', 'png', 'gif', 'jpeg'];

        if ($_FILES['avatar']['size'] <= $maxSize) {
            $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));

            if (in_array($extensionUpload, $extensions)) {
                $save = "libraries/members/avatars/" . $_SESSION['id'] . "." . $extensionUpload;
                $result = move_uploaded_file($_FILES['avatar']['tmp_name'], $save);
                if ($result) {
                    $avatar = $_SESSION['id'] . "." . $extensionUpload;
                    //return true;
                    return [true, $avatar];
                } else {
                    $error = 'Il y a eu une erreur pendant l\'importation de votre document';
                }
            } else {
                $error = 'Votre photo doit être au format JPG, JPEG, PNG ou GIF';
            }
        } else {
            $error = 'Votre photo de profil ne doit pas dépasser 2Mo';
        }

        return $error;
    }


    // Vérification du fichier posté
    public static function file($countfiles, $extensions)
    {
        for ($i = 0; $i < $countfiles; $i++) {
            $extensionUpload = strtolower(substr(strrchr($_FILES['pictures']['name'][$i], '.'), 1));

            if (!in_array($extensionUpload, $extensions))
            {
                $error = 'Votre photo doit être au format JPG, JPEG, PNG, GIF, MOV, MP4, AVI, FLV ou WMV';
                return $error;
            } else {
                $file = true;
            }
        }
        return [$file, $extensionUpload];
    }
}
